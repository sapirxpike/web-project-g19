import concurrent
import os.path

import mysqlx.connection
from flask import Blueprint, render_template, redirect, url_for, request, session, Flask
import mysql.connector

mydb=mysql.connector.connect(
    host='localhost',
    user='root',
    password='Amber1958',
    port='3306',
    database='foodworld'
)

mycursor=mydb.cursor()

#concurrent = as.path.dirname(os.path.abspath(_file))

app = Flask(__name__)






@app.route('/index')
@app.route('/')
def foodworld_website():
    # DB
    found = True
    if found:
        return render_template('index.html',name='sapir')
    else:
        return render_template('index.html')





@app.route('/about_us')
def aboutus_page():
        return render_template('about_us.html')


@app.route('/recommendation_page')
def recommendation_page():
        return render_template('recommendation_page.html')

@app.route('/giftcard')
def giftcard():
        return render_template('giftcard.html')

@app.route('/food_world')
def food_world():
        return render_template('food_world.html')


@app.route('/recpie_page')
def recipe_page():
        return render_template('recpie_page.html')



@app.route('/registration')
def registration_Page():
    return render_template('registration.html')



@app.route('/registration', methods=["GET,POST"])
def registration1_Page():
    if request.method == "POST":
        USERNAME = request.form['email']
        PASSWORD = request.form['pass']
        sqlconnection = mysql.connection(concurrent + "\customers.db")
        cursor = sqlconnection.cursor()
        query1 = "insert into customers values ('{u}','{p}')".format(u=USERNAME,p=PASSWORD )
        cursor.execute(query1)
        sqlconnection.commit()
        return redirect("/index")
    return render_template('registration.html')


@app.route('/login')
def login_Page():
    return render_template('login.html')



@app.route('/login' , methods = ["POST"])
def login_Page1():
    USERNAME = request.form['email']
    PASSWORD = request.form['pass']

    sqlconnection = mysql.connection(concurrent + "\customers.db")
    cursor = sqlconnection.cursor()
    query1 = "SELECT email ,pass FROM customers WHERE email = {UN} AND pass = {PW} ".format(UN=USERNAME, PW=PASSWORD)

    rows = cursor.execute(query1)
    rows = rows.fetchall()
    if len(rows) == 1:
        return render_template('index.html')
    else:
        return redirect("/registration")

    return render_template('index.html')

@app.route('/policy')
def policy_Page():
        return render_template('policy.html')


@app.route('/customer_service')
def customer_service_Page():
        return render_template('customer_service.html')



if __name__ == '__main__':
    app.run(debug=True)


