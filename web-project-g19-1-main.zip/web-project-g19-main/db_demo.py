import mysql.connector
foodworld_db = mysql.connector.connect(host="localhost", user="root", password="Amber1958")
print(foodworld_db)

mycursor = foodworld_db.cursor()


mycursor.execute("select * from FOODWORLD.CUSTOMERS;")
