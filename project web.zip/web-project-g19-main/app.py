from flask import Blueprint, render_template, redirect, url_for, request, session, Flask



app = Flask(__name__)


@app.route('/index')
@app.route('/')
def foodworld_website():
    # DB
    found = True
    if found:
        return render_template('index.html',name='sapir')
    else:
        return render_template('index.html')





@app.route('/about_us')
def aboutus_page():
        return render_template('about_us.html')


@app.route('/recommendation_page')
def recommendation_page():
        return render_template('recommendation_page.html')

@app.route('/giftcard')
def giftcard():
        return render_template('giftcard.html')

@app.route('/food_world')
def food_world():
        return render_template('food_world.html')


@app.route('/recpie_page')
def recipe_page():
        return render_template('recpie_page.html')


@app.route('/registration')
def registration_Page():
        return render_template('registration.html')

@app.route('/login')
def login_Page():
        return render_template('login.html')

@app.route('/policy')
def policy_Page():
        return render_template('policy.html')


@app.route('/customer_service')
def customer_service_Page():
        return render_template('customer_service.html')



if __name__ == '__main__':
    app.run(debug=True)


